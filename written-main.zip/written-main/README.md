this is not worth reading
